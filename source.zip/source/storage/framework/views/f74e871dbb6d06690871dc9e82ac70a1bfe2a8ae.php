<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Vòng Quay')); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('img/vongquay/logo180.png')); ?>">
    <link rel="icon" href="<?php echo e(asset('img/vongquay/logo180.png')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.blockUI.js')); ?>"></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/result.css?v=1')); ?><?php echo time(); ?>" rel="stylesheet">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <table class="table table-dark table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Cửa hàng</th>
                            <th scope="col">Phần thưởng</th>
                            <th scope="col">Code</th>
                            <th scope="col">Tên</th>
                            <th scope="col">SĐT</th>
                            <th scope="col">Địa chỉ</th>
                            <th scope="col">Ngày</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($oHistories): ?>
                        <?php $__currentLoopData = $oHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($oHistory->id); ?></td>
                            <td><?php if($oHistory->store): ?> <?php echo e($oHistory->store->name); ?> <?php endif; ?></td>
                            <td><?php if($oHistory->item): ?> <?php echo e($oHistory->item->name); ?> <?php endif; ?></td>
                            <td><?php if($oHistory->code): ?> <?php echo e($oHistory->code->code); ?> <?php endif; ?></td>
                            <td><?php echo e($oHistory->name); ?></td>
                            <td><?php echo e($oHistory->phone); ?></td>
                            <td><?php echo e($oHistory->address); ?></td>
                            <td><?php echo e($oHistory->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /Users/mac/PhpstormProjects/VongQuay/source/resources/views/vong-quay/result.blade.php ENDPATH**/ ?>